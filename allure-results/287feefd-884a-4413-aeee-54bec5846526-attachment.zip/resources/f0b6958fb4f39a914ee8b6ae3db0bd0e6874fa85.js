(function(){
    var clientId = "__CLIENT_ID__";
  })();

